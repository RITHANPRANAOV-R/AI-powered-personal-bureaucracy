"""Deterministic visible-browser driver for RTI Online and Passport Seva workflows.

HARD INVARIANT: The browser is NEVER closed by an exception. Any error outside the final
'close now' step prints the error, keeps the browser open, sets ExecutionStatus.FAILED, and
waits for the user to press Enter before closing.
"""

from __future__ import annotations

import sys
import traceback
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from agents.execution_assistance.safety import check_host_allowlist, is_secret_field, mask_sensitive_value
from agents.execution_assistance.schema import (
    CONTRACT_VERSION,
    ExecutionRequest,
    ExecutionResult,
    ExecutionStatus,
    FieldActionRecord,
    PortalObservation,
    StepExecutionResult,
    StepExecutionStatus,
    UserPausePoint,
)
from agents.user_context.schema import ProfileFact

from src.bureaucracy_agent.orchestrator.hosts import get_allowed_hosts
from src.bureaucracy_agent.orchestrator.logging_setup import log_stage
from src.bureaucracy_agent.portal.extract import extract_confirmation_details
from src.bureaucracy_agent.portal.prompts import (
    PAYMENT_PAUSE_BANNER,
    REVIEW_CHECKPOINT_FOOTER,
    REVIEW_CHECKPOINT_HEADER,
    SECURITY_PAUSE_BANNER,
)
from src.bureaucracy_agent.portal.selectors import (
    PASSPORT_SELECTORS,
    REGISTRATION_SELECTORS,
    REGISTRATION_URLS,
    RTI_FORM_SELECTORS,
    RTI_GUIDELINES_SELECTORS,
    RTI_REGISTRATION_URLS,
)


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


class PortalBrowserDriver:
    """Deterministic, human-in-the-loop Playwright browser driver for RTI Online & Passport Seva."""

    def __init__(self, allowed_hosts: Optional[List[str]] = None) -> None:
        self.allowed_hosts = allowed_hosts or get_allowed_hosts("execution")

    def execute_live_flow(
        self,
        request: ExecutionRequest,
        interactive: bool = True,
        stop_before_submit: bool = False,
        on_submission_attempted_cb: Optional[Any] = None,
    ) -> ExecutionResult:
        """
        Execute target browser automation flow with strict error-recovery invariant.

        Browser is NEVER closed by an exception. Any error keeps the browser open,
        prints stack trace, sets FAILED status, and waits for Enter before closing.
        """
        started_at = utc_now()
        field_actions: List[FieldActionRecord] = []
        user_pause_points: List[UserPausePoint] = []
        portal_observations: List[PortalObservation] = []
        warnings: List[str] = list(request.workflow_plan.warnings if request.workflow_plan else [])
        step_results: List[StepExecutionResult] = []

        selected_steps = request.selected_step_ids or ["user-controlled-portal-action"]
        main_step_id = selected_steps[0]

        # Stage 1: LAUNCH
        log_stage("LAUNCH", "Starting Playwright visible Chromium browser session")
        try:
            from playwright.sync_api import sync_playwright
        except ImportError as exc:
            # Pre-flight error before browser launch (Allowable closure path a)
            print(f"[FATAL PREFLIGHT] Playwright import failed: {exc}")
            return ExecutionResult(
                contract_version=CONTRACT_VERSION,
                execution_request_id=request.execution_request_id,
                request_id=request.request_id,
                plan_id=request.workflow_plan.plan_id if request.workflow_plan else "plan-1",
                plan_version=request.workflow_plan.plan_version if request.workflow_plan else 1,
                validation_request_id=request.validation_result.validation_request_id,
                execution_status=ExecutionStatus.FAILED,
                warnings=[f"Playwright import failed: {exc}"],
                completed_at=utc_now(),
            )

        browser = None
        page = None

        def handle_flow_error(exc: Exception, stage_name: str) -> ExecutionResult:
            """Handle non-preflight exceptions: print stack trace, keep browser open, wait for Enter."""
            err_msg = f"Error during stage '{stage_name}': {type(exc).__name__}: {exc}"
            print(f"\n================================================================================")
            print(f"               DRIVER ERROR OCCURRED IN STAGE: {stage_name}")
            print(f"================================================================================")
            print(f"{err_msg}\n")
            traceback.print_exc()
            print("\nINVARIANT ACTIVE: The browser window is kept open for inspection.")
            if interactive:
                try:
                    input("Press ENTER to close the browser window... ")
                except (EOFError, KeyboardInterrupt):
                    pass
            if browser:
                try:
                    browser.close()
                except Exception:  # noqa: BLE001
                    pass
            return ExecutionResult(
                contract_version=CONTRACT_VERSION,
                execution_request_id=request.execution_request_id,
                request_id=request.request_id,
                plan_id=request.workflow_plan.plan_id if request.workflow_plan else "plan-1",
                plan_version=request.workflow_plan.plan_version if request.workflow_plan else 1,
                validation_request_id=request.validation_result.validation_request_id,
                execution_status=ExecutionStatus.FAILED,
                warnings=warnings + [err_msg],
                completed_at=utc_now(),
            )

        try:
            with sync_playwright() as p:
                # Launch maximized window
                browser = p.chromium.launch(
                    headless=False,
                    args=["--start-maximized"],
                )
                context = browser.new_context(viewport={"width": 1400, "height": 1000})
                page = context.new_page()
                page.bring_to_front()

                viewport_size = page.viewport_size or {"width": 1400, "height": 1000}
                log_stage("LAUNCH", f"Browser window opened with viewport {viewport_size['width']}x{viewport_size['height']}")

                # Determine target URL & Portal type
                target_url = request.starting_url or RTI_REGISTRATION_URLS[0]
                is_rti = "rtionline" in target_url.lower() or "rti" in (request.intent.service_name or "").lower()
                if is_rti and not request.starting_url:
                    target_url = "https://rtionline.gov.in/guidelines.php?request"

                # Stage 2: NAVIGATE
                log_stage("NAVIGATE", f"Opening target URL: {target_url}")
                if not check_host_allowlist(target_url, self.allowed_hosts):
                    return handle_flow_error(ValueError(f"URL '{target_url}' is not on host allowlist."), "NAVIGATE")

                try:
                    page.goto(target_url, timeout=30000, wait_until="domcontentloaded")
                except Exception as exc:  # noqa: BLE001
                    return handle_flow_error(exc, "NAVIGATE")

                # Handle RTI Guidelines page check & submit if present
                if is_rti and "guidelines.php" in page.url:
                    log_stage("NAVIGATE", "RTI Guidelines page detected: Accepting guidelines checkbox")
                    try:
                        for loc in RTI_GUIDELINES_SELECTORS["checkbox"]["locators"]:
                            if page.is_visible(loc, timeout=1000):
                                page.check(loc)
                                break

                        for loc in RTI_GUIDELINES_SELECTORS["submit_button"]["locators"]:
                            if page.is_visible(loc, timeout=1000):
                                page.click(loc)
                                break
                        page.wait_for_timeout(1500)
                    except Exception as exc:  # noqa: BLE001
                        log_stage("NAVIGATE", f"Guidelines navigation note: {exc}")

                current_url = page.url
                if not check_host_allowlist(current_url, self.allowed_hosts):
                    return handle_flow_error(ValueError(f"Redirected host '{current_url}' not allowed."), "NAVIGATE")

                portal_observations.append(
                    PortalObservation(
                        page_title=page.title(),
                        url=current_url,
                        visible_status="Opened request form page",
                        observed_at=utc_now(),
                    )
                )

                # Select active selector map
                active_selectors = RTI_FORM_SELECTORS if is_rti else REGISTRATION_SELECTORS

                # Stage 3: FILL non-secret confirmed facts only
                log_stage("FILL", "Filling non-secret form fields from confirmed facts")
                facts_by_key = {f.key: f.value for f in request.confirmed_facts if f.confirmed_by_user}

                if request.dry_run:
                    log_stage("DRY_RUN", "Dry-run mode active: form inspected, no values typed, no submit")
                    print("\n[DRY RUN] Inspection complete. Press ENTER to close browser...")
                    if interactive:
                        input()
                    browser.close()
                    step_results.append(
                        StepExecutionResult(
                            step_id=main_step_id,
                            status=StepExecutionStatus.COMPLETED,
                            action_summary="Dry-run simulation complete. Prepared form for review.",
                            started_at=started_at,
                            completed_at=utc_now(),
                        )
                    )
                    return ExecutionResult(
                        contract_version=CONTRACT_VERSION,
                        execution_request_id=request.execution_request_id,
                        request_id=request.request_id,
                        plan_id=request.workflow_plan.plan_id,
                        plan_version=request.workflow_plan.plan_version,
                        validation_request_id=request.validation_result.validation_request_id,
                        execution_status=ExecutionStatus.PREPARED_FOR_REVIEW,
                        step_results=step_results,
                        user_pause_points=user_pause_points,
                        portal_observations=portal_observations,
                        submission_attempted=False,
                        confirmation_observed=False,
                        warnings=warnings,
                        completed_at=utc_now(),
                    )

                # Live Fill attempt
                for field_id, field_spec in active_selectors.items():
                    if field_spec.get("is_secret"):
                        continue

                    prof_key = field_spec.get("profile_key")
                    val = facts_by_key.get(prof_key) if prof_key else None
                    field_label = field_spec["labels"][0]

                    if prof_key == "given_name" and not val and "full_name" in facts_by_key:
                        val = facts_by_key["full_name"]

                    if not val:
                        field_actions.append(
                            FieldActionRecord(
                                field_label=field_label,
                                approval_id="exec-appr",
                                outcome="manual_required",
                                masked_value="[EMPTY]",
                            )
                        )
                        continue

                    filled = False
                    for locator_str in field_spec["locators"]:
                        try:
                            if page.is_visible(locator_str, timeout=1000):
                                if field_spec["type"] == "input":
                                    page.fill(locator_str, str(val))
                                    filled = True
                                    break
                                elif field_spec["type"] == "textarea":
                                    page.fill(locator_str, str(val))
                                    filled = True
                                    break
                                elif field_spec["type"] == "select":
                                    page.select_option(locator_str, label=str(val))
                                    filled = True
                                    break
                        except Exception:  # noqa: BLE001
                            continue

                    masked = mask_sensitive_value(prof_key or field_label, str(val))
                    outcome = "filled" if filled else "manual_required"
                    field_actions.append(
                        FieldActionRecord(
                            field_label=field_label,
                            approval_id="exec-appr",
                            outcome=outcome,
                            masked_value=masked,
                        )
                    )

                # Stage 4: CAPTCHA VISIBILITY
                log_stage("CAPTCHA_VISIBILITY", "Locating CAPTCHA element and scrolling into view")
                captcha_spec = active_selectors.get("captcha_image") or active_selectors.get("captcha_input")
                captcha_visible = False

                if captcha_spec:
                    for loc in captcha_spec["locators"]:
                        try:
                            if page.is_visible(loc, timeout=1500):
                                page.locator(loc).scroll_into_view_if_needed()
                                captcha_visible = True
                                break
                        except Exception:  # noqa: BLE001
                            continue

                print(SECURITY_PAUSE_BANNER)
                print("CAPTCHA is now visible in the browser window — enter it in the browser, then press Enter here.\n")

                pause_rec = UserPausePoint(
                    step_id=main_step_id,
                    reason="CAPTCHA / Security challenge",
                    paused_at=utc_now(),
                )
                user_pause_points.append(pause_rec)

                if interactive:
                    try:
                        input("Press ENTER after entering CAPTCHA in the browser... ")
                    except (EOFError, KeyboardInterrupt):
                        pass

                pause_rec.resumed_at = utc_now()
                pause_rec.resume_status = "resumed_by_user"

                # Stage 5: REVIEW
                log_stage("REVIEW", "Scrolling to top and presenting form review table")
                try:
                    page.evaluate("window.scrollTo(0, 0)")
                except Exception:  # noqa: BLE001
                    pass

                print(REVIEW_CHECKPOINT_HEADER)
                print(f"{'FIELD LABEL':<40} | {'OUTCOME':<15} | {'PREPARED VALUE'}")
                print("-" * 75)
                for fa in field_actions:
                    print(f"{fa.field_label:<40} | {fa.outcome:<15} | {fa.masked_value}")
                print(REVIEW_CHECKPOINT_FOOTER)

                if stop_before_submit:
                    log_stage("STOP_BEFORE_SUBMIT", "Review table displayed. Stopping execution before submission (--stop-before-submit active).")
                    print("\n[STOP_BEFORE_SUBMIT] Browser window stays open for inspection. Press ENTER to close...")
                    if interactive:
                        try:
                            input()
                        except (EOFError, KeyboardInterrupt):
                            pass
                    browser.close()
                    step_results.append(
                        StepExecutionResult(
                            step_id=main_step_id,
                            status=StepExecutionStatus.COMPLETED,
                            action_summary="stopped before submission (demo mode)",
                            started_at=started_at,
                            completed_at=utc_now(),
                        )
                    )
                    return ExecutionResult(
                        contract_version=CONTRACT_VERSION,
                        execution_request_id=request.execution_request_id,
                        request_id=request.request_id,
                        plan_id=request.workflow_plan.plan_id,
                        plan_version=request.workflow_plan.plan_version,
                        validation_request_id=request.validation_result.validation_request_id,
                        execution_status=ExecutionStatus.PREPARED_FOR_REVIEW,
                        step_results=step_results,
                        field_actions=field_actions,
                        user_pause_points=user_pause_points,
                        portal_observations=portal_observations,
                        submission_attempted=False,
                        confirmation_observed=False,
                        warnings=warnings,
                        completed_at=utc_now(),
                    )

                # Stage 6: CONFIRM_SUBMISSION phrase
                typed_phrase = ""
                if interactive:
                    try:
                        typed_phrase = input("Type 'CONFIRM SUBMISSION' to proceed with submit: ").strip()
                    except (EOFError, KeyboardInterrupt):
                        typed_phrase = ""

                if typed_phrase != "CONFIRM SUBMISSION":
                    log_stage("CANCELLED", "User typed non-submission phrase. Submission cancelled; browser stays open.")
                    print("\n[CANCELLED] Submission cancelled. The browser window stays open — press ENTER to close...")
                    if interactive:
                        try:
                            input()
                        except (EOFError, KeyboardInterrupt):
                            pass
                    browser.close()
                    return ExecutionResult(
                        contract_version=CONTRACT_VERSION,
                        execution_request_id=request.execution_request_id,
                        request_id=request.request_id,
                        plan_id=request.workflow_plan.plan_id,
                        plan_version=request.workflow_plan.plan_version,
                        validation_request_id=request.validation_result.validation_request_id,
                        execution_status=ExecutionStatus.CANCELLED,
                        field_actions=field_actions,
                        user_pause_points=user_pause_points,
                        portal_observations=portal_observations,
                        submission_attempted=False,
                        confirmation_observed=False,
                        warnings=["User typed non-submission phrase; submission cancelled."],
                        completed_at=utc_now(),
                    )

                log_stage("CONFIRM_SUBMISSION", "Typed 'CONFIRM SUBMISSION' received")

                # Write pre-submit marker BEFORE click
                if on_submission_attempted_cb:
                    on_submission_attempted_cb()

                # Stage 6 Click Submit
                log_stage("SUBMIT", "Clicking submit button on official page")
                submit_spec = active_selectors["submit_button"]
                submitted = False

                for loc in submit_spec["locators"]:
                    try:
                        if page.is_visible(loc, timeout=2000):
                            page.click(loc)
                            submitted = True
                            break
                    except Exception:  # noqa: BLE001
                        continue

                if not submitted and interactive:
                    print("\n[SUBMIT FALLBACK] Could not automatically locate submit button.")
                    input("Please click Submit in the browser yourself, then press ENTER here... ")

                # Stage 7: POST_SUBMIT
                log_stage("POST_SUBMIT", "Waiting for post-submission page load")
                try:
                    page.wait_for_timeout(3000)
                except Exception:  # noqa: BLE001
                    pass

                print(f"[POST_SUBMIT] Page Title: {page.title()}")
                print(f"[POST_SUBMIT] Page URL  : {page.url}")

                page_text = page.inner_text("body")
                observed, ref_str, ext_details = extract_confirmation_details(page_text)

                portal_observations.append(
                    PortalObservation(
                        page_title=page.title(),
                        url=page.url,
                        visible_status=ref_str or "Submitted, reading confirmation details",
                        observed_at=utc_now(),
                    )
                )

                # Stage 8: FINAL
                log_stage("FINAL", "Displaying extracted confirmation details and awaiting user close confirmation")
                print("\n================================================================================")
                print("                  OFFICIAL PORTAL CONFIRMATION DETAILS")
                print("================================================================================")
                if observed and ref_str:
                    print(f" Reference String  : {ref_str}")
                    for k, v in ext_details.items():
                        print(f"   - {k:<25} : {v}")
                else:
                    print(" Confirmation       : Submission attempted; no labelled registration reference extracted.")

                print("\nPress ENTER to close the browser window...")
                if interactive:
                    try:
                        input()
                    except (EOFError, KeyboardInterrupt):
                        pass

                browser.close()

                final_status = ExecutionStatus.CONFIRMATION_OBSERVED if observed else ExecutionStatus.UNCERTAIN
                step_results.append(
                    StepExecutionResult(
                        step_id=main_step_id,
                        status=StepExecutionStatus.COMPLETED if observed else StepExecutionStatus.NEEDS_USER_INPUT,
                        action_summary="Submitted request form on official portal.",
                        started_at=started_at,
                        completed_at=utc_now(),
                    )
                )

                return ExecutionResult(
                    contract_version=CONTRACT_VERSION,
                    execution_request_id=request.execution_request_id,
                    request_id=request.request_id,
                    plan_id=request.workflow_plan.plan_id,
                    plan_version=request.workflow_plan.plan_version,
                    validation_request_id=request.validation_result.validation_request_id,
                    execution_status=final_status,
                    step_results=step_results,
                    field_actions=field_actions,
                    user_pause_points=user_pause_points,
                    portal_observations=portal_observations,
                    submission_attempted=True,
                    confirmation_observed=observed,
                    confirmation_reference=ref_str,
                    warnings=warnings,
                    completed_at=utc_now(),
                )

        except Exception as exc:  # noqa: BLE001
            return handle_flow_error(exc, "UNHANDLED_EXCEPTION")


# Backward compatibility alias
PassportSevaDriver = PortalBrowserDriver
