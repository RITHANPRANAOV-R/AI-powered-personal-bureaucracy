"""Single source of truth for allowed-host sets and official source registries."""

from __future__ import annotations

from typing import List
from agents.information_retrieval.schema import OfficialSourceSpec

RETRIEVAL_HOSTS: List[str] = [
    "passportindia.gov.in",
    "www.passportindia.gov.in",
    "portal2.passportindia.gov.in",
    "services2.passportindia.gov.in",
    "mea.gov.in",
    "www.mea.gov.in",
    "rtionline.gov.in",
    "www.rtionline.gov.in",
]

EXECUTION_HOSTS: List[str] = [
    "passportindia.gov.in",
    "www.passportindia.gov.in",
    "services2.passportindia.gov.in",
    "rtionline.gov.in",
    "www.rtionline.gov.in",
]

# Union of retrieval and execution hosts
UNION_HOSTS: List[str] = list(sorted(set(RETRIEVAL_HOSTS + EXECUTION_HOSTS)))

# Registry of official source URLs for retrieval
OFFICIAL_SOURCE_REGISTRY: List[OfficialSourceSpec] = [
    # RTI Online portal
    OfficialSourceSpec(
        source_id="rti_home",
        url="https://rtionline.gov.in/",
        title="RTI Online Portal India",
        category="portal",
    ),
    OfficialSourceSpec(
        source_id="rti_submit",
        url="https://rtionline.gov.in/request/request.php",
        title="RTI Online Submit Request Form",
        category="registration",
    ),
    # Passport Seva portal
    OfficialSourceSpec(
        source_id="ps_home",
        url="https://www.passportindia.gov.in/AppOnlineProject/welcomeLink",
        title="Passport Seva main portal",
        category="portal",
    ),
    OfficialSourceSpec(
        source_id="ps_register_current",
        url="https://services2.passportindia.gov.in/forms/registration",
        title="Passport Seva user registration portal",
        category="registration",
    ),
    OfficialSourceSpec(
        source_id="ps_register_alt",
        url="https://www.passportindia.gov.in/forms/registration",
        title="Passport Seva registration form",
        category="registration",
    ),
    OfficialSourceSpec(
        source_id="ps_register_legacy",
        url="https://passportindia.gov.in/AppOnlineProject/user/RegistrationBaseAction",
        title="Passport Seva legacy user registration",
        category="registration",
    ),
    OfficialSourceSpec(
        source_id="ps_steps_pdf",
        url="https://www.passportindia.gov.in/AppOnlineProject/pdf/steps_to_apply_for_passport_services.pdf",
        title="Steps to apply for passport services",
        category="procedure",
    ),
    OfficialSourceSpec(
        source_id="ps_fresh_docs",
        url="https://passportindia.gov.in/AppOnlineProject/docAdvisor/attachmentAdvFreshInp",
        title="Documents required for fresh passport",
        category="documents",
    ),
    OfficialSourceSpec(
        source_id="mea_passport",
        url="https://www.mea.gov.in/passport-for-indian-nationals.htm",
        title="Ministry of External Affairs — Passport for Indian nationals",
        category="ministry",
    ),
]


def get_allowed_hosts(purpose: str = "union") -> List[str]:
    """Return host allowlist for a specific purpose."""
    if purpose == "retrieval":
        return list(RETRIEVAL_HOSTS)
    elif purpose == "execution":
        return list(EXECUTION_HOSTS)
    return list(UNION_HOSTS)


def get_official_source_registry() -> List[OfficialSourceSpec]:
    """Return official source registry specs for retrieval."""
    return list(OFFICIAL_SOURCE_REGISTRY)
